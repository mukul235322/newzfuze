<?php include("../../path.php"); ?>
<!DOCTYPE html>
<html>
<head>

	<!--Font Awesome-->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" integrity="sha384-v8BU367qNbs/aIZIxuivaU55N5GPF89WBerHoGA4QTcbUjYiLQtKdrfXnqAcXyTv" crossorigin="anonymous">

	<title>Admin Section - Edit User</title>
	<!--Custom Syting-->

	<link rel="stylesheet"  href="../../assests/css/style.css">

	<!--Admin Syting-->
	
	<link rel="stylesheet"  href="../../assests/css/admin.css">

</head>

<body>

    <?php include(ROOT_PATH . "/app/includes/adminHeader.php"); ?>


	<!-- Admin Page wrapper -->
    <div class="admin-wrapper">

		<!--Left sidebar-->
		<?php include(ROOT_PATH . "/app/includes/adminSidebar.php"); ?>
		<!--//Left sidebar-->

		<!--admin content-->
		<div class="admin-content">
			<div class="button-group">
				<a href="create.php" class="btn btn-big"> Add User</a>
				<a href="index.php" class="btn btn-big"> Manage Users</a>
			</div>

			<div class="content">
				<h2 class="page-title">Edit User</h2>
				<form action="create.html" method="post">
					<div>
						<label>Username</label>
						<input type="text" name="username" class="text-input">
					</div>
					<div>
						<label>Email</label>
						<input type="email" name="email" class="text-input">
					</div>
					<div>
						<label>Password</label>
						<input type="password" name="password" class="text-input">
					</div>
					<div>
						<label>Confirm Password</label>
						<input type="password" name="passwordConf" class="text-input">
					</div>
					<div>
						<label>Role</label>

						<select name="topic" class="text-input">
							<option value="Author">Author</option>

							<option value="Admin">Admin</option>
						</select>
					</div>
					
					<div>
						<button type="submit" class="btn btn-big">Update User</button>
					</div>
					
				</form>


				
				

			</div>
			

		</div>
        <!--//admin content-->		

		

	</div>
	<!--// Admin Page wrapper-->

	

	<!-- Jquery -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

	<!-- Ckeditor-->
	<script src="https://cdn.ckeditor.com/ckeditor5/17.0.0/classic/ckeditor.js"></script>



	<!-- Custom Script-->
	<script src="../../assests/js/script.js"></script>

</body>
</html>