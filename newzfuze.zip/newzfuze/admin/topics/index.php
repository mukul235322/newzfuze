<?php include("../../path.php"); ?>
<?php include(ROOT_PATH . "/app/controllers/topics.php"); ?>
<!DOCTYPE html>
<html>
<head>

	<!--Font Awesome-->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" integrity="sha384-v8BU367qNbs/aIZIxuivaU55N5GPF89WBerHoGA4QTcbUjYiLQtKdrfXnqAcXyTv" crossorigin="anonymous">

	<title>Admin Section - Manage Topic</title>
	<!--Custom Syting-->

	<link rel="stylesheet"  href="../../assests/css/style.css">

	<!--Admin Syting-->
	
	<link rel="stylesheet"  href="../../assests/css/admin.css">

</head>

<body>

    <?php include("../../app/includes/adminHeader.php"); ?>


	<!-- Admin Page wrapper -->
    <div class="admin-wrapper">

		<!--Left sidebar-->
		<?php include(ROOT_PATH . "/app/includes/adminSidebar.php"); ?>
		<!--//Left sidebar-->

		<!--admin content-->
		<div class="admin-content">
			<div class="button-group">
				<a href="create.php" class="btn btn-big"> Add Topics</a>
				<a href="index.php" class="btn btn-big"> Manage Topics</a>
			</div>

			<div class="content">
				<h2 class="page-title">Manage Topics</h2>

				<?php include(ROOT_PATH . "/app/includes/messages.php"); ?>

				<table>
					<thead>
						<th>SN</th>
						<th>Name</th>
						<th colspan="2">Action</th>
					</thead>
					<tbody>
						<tr>
							<td>1</td>
							<td>Poetry</td>
						
							<td><a href="#" class="edit">edit</a></td>
							<td><a href="#" class="delete">delete</a></td>
						</tr>
						<tr>
							<td>2</td>
							<td>Life Lessons</td>
							
							<td><a href="#" class="edit">edit</a></td>
							<td><a href="#" class="delete">delete</a></td>
						
						</tr>
						
						
					</tbody>
				</table>
				

			</div>
			

		</div>
        <!--//admin content-->		

		

	</div>
	<!--// Admin Page wrapper-->

	

	<!-- Jquery -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

	<!-- Ckeditor-->
	<script src="https://cdn.ckeditor.com/ckeditor5/17.0.0/classic/ckeditor.js"></script>



	<!-- Custom Script-->
	<script src="../../assests/js/script.js"></script>

</body>
</html>