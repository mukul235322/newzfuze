<?php include("../../path.php"); ?>
<?php include(ROOT_PATH . "/app/controllers/topics.php"); ?>

<!DOCTYPE html>
<html>
<head>

	<!--Font Awesome-->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" integrity="sha384-v8BU367qNbs/aIZIxuivaU55N5GPF89WBerHoGA4QTcbUjYiLQtKdrfXnqAcXyTv" crossorigin="anonymous">

	<title>Admin Section - Add Topic</title>
	<!--Custom Syting-->

	<link rel="stylesheet"  href="../../assests/css/style.css">

	<!--Admin Syting-->
	
	<link rel="stylesheet"  href="../../assests/css/admin.css">

</head>

<body>


    <?php include(ROOT_PATH . "/app/includes/adminHeader.php"); ?>


	<!-- Admin Page wrapper -->
    <div class="admin-wrapper">

		<!--Left sidebar-->
		<?php include(ROOT_PATH . "/app/includes/adminSidebar.php"); ?>
		<!--//Left sidebar-->

		<!--admin content-->
		<div class="admin-content">
			<div class="button-group">
				<a href="create.php" class="btn btn-big"> Add Topic</a>
				<a href="index.php" class="btn btn-big"> Manage Topic</a>
			</div>

			<div class="content">
				<h2 class="page-title">Add Topic</h2>
				<form action="create.php" method="post">
					<div>
						<label>Name</label>
						<input type="text" name="title" class="text-input">

					</div>
					<div>
						<label>Description</label>
						<textarea name="description" id ="body"></textarea>
					</div>
					
					<div>
						<button type="submit" name="add-topic" class="btn btn-big">Add topic</button>
					</div>
				</form>
            </div>
			

		</div>

        <!--//admin content-->		

		

	</div>
	<!--// Admin Page wrapper-->

	

	<!-- Jquery -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

	<!-- Ckeditor-->
	<script src="https://cdn.ckeditor.com/ckeditor5/17.0.0/classic/ckeditor.js"></script>



	<!-- Custom Script-->
	<script src="../../assests/js/script.js"></script>

</body>
</html>