<?php 
include("path.php"); 
include(ROOT_PATH . "/app/database/db.php");
?>

<!DOCTYPE html>
<html>
<head>

	<!--Font Awesome-->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" integrity="sha384-v8BU367qNbs/aIZIxuivaU55N5GPF89WBerHoGA4QTcbUjYiLQtKdrfXnqAcXyTv" crossorigin="anonymous">

	<title>NewzFuze</title>
	<link rel="stylesheet" type="text/css" href="assests/css/style.css">

</head>
<body>
	<?php include(ROOT_PATH . "/app/includes/header.php"); ?>
	<?php include(ROOT_PATH . "/app/includes/messages.php"); ?>


	
	

	<!-- Page wrapper -->


	<div class="page-wrapper">

		<!--post slider-->
		<div class="post-slider">
			<h1 class="slider-title">Trending Posts</h1>
			<i class="fas fa-chevron-left prev"></i>
			<i class="fas fa-chevron-right next"></i>

			<div class="post-wrapper">

				<div class="post">
					<img src="assests/images/image2.jpg" alt="" class="slider-image">
					<div class="post-info">
						<h4><a href="single.html">One day your life will flash before your eyes</a></h4>
						<i class="fas fa-user"> Mukul Chauhan</i>
						&nbsp;
						<i class="far fa-calendar"> Mar 8, 2019</i>

					</div>
				</div>


				<div class="post">
					<img src="assests/images/image3.jpg" alt="" class="slider-image">
					<div class="post-info">
						<h4><a href="single.html"> Live for your happiness and always do that</a></h4>
						<i class="fas fa-user"> Alvina Singh</i>
						&nbsp;
						<i class="far fa-calendar"> Mar 4, 2020</i>

					</div>
				</div>


				<div class="post">
					<img src="assests/images/image4.jpg" alt="" class="slider-image">
					<div class="post-info">
						<h4><a href="single.html">One day your life will flash before your eyes</a></h4>
						<i class="fas fa-user"> Mukul Chauhan</i>
						&nbsp;
						<i class="far fa-calendar"> Mar 8, 2019</i>

					</div>
				</div>


				<div class="post">
					<img src="assests/images/image5.jpg" alt="" class="slider-image">
					<div class="post-info">
						<h4><a href="single.html">One day your life will flash before your eyes</a></h4>
						<i class="fas fa-user"> Mukul Chauhan</i>
						&nbsp;
						<i class="far fa-calendar"> Mar 8, 2019</i>

					</div>
				</div>


				<div class="post">
					<img src="assests/images/image6.jpg" alt="" class="slider-image">
					<div class="post-info">
						<h4><a href="single.html">One day your life will flash before your eyes</a></h4>
						<i class="fas fa-user"> Mukul Chauhan</i>
						&nbsp;
						<i class="far fa-calendar"> Mar 8, 2019</i>

					</div>
				</div>

				<div class="post">
					<img src="assests/images/image7.jpg" alt="" class="slider-image">
					<div class="post-info">
						<h4><a href="single.html">One day your life will flash before your eyes</a></h4>
						<i class="fas fa-user"> Mukul Chauhan</i>
						&nbsp;
						<i class="far fa-calendar"> Mar 8, 2019</i>

					</div>
				</div>
				
			</div>
			
		</div>

		<!--//post slider-->

		<!-- Content -->
		<div class="content clearfix">

			<!-- Main content-->

			<div class="main-content">
				<h1 class="recent-post-title">Recent Posts</h1>

				<div class="post clearfix">
					<img src="assests/images/image6.jpg" alt="" class="post-image">

					<div class="post-preview">
						<h2><a href="single.html">The strongest and sweetest songs yet remain to be sung</a></h2>
						<i class="fas fa-user"> Mukul Chauhan</i>
						&nbsp;
						<i class="far calendar">May 11, 2019</i>
						<p class="preview-text">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							
						</p>
						<a href="single.html" class="btn read-more">Read More</a>
						
					</div>

				</div>

				<div class="post clearfix">
					<img src="assests/images/image5.jpg" alt="" class="post-image">

					<div class="post-preview">
						<h2><a href="single.html">The strongest and sweetest songs yet remain to be sung</a></h2>
						<i class="fas fa-user"> Mukul Chauhan</i>
						&nbsp;
						<i class="far calendar">May 11, 2019</i>
						<p class="preview-text">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							
						</p>
						<a href="single.html" class="btn read-more">Read More</a>
						
					</div>

				</div>

				<div class="post clearfix">
					<img src="assests/images/image7.jpg" alt="" class="post-image">

					<div class="post-preview">
						<h2><a href="single.html">The strongest and sweetest songs yet remain to be sung</a></h2>
						<i class="fas fa-user"> Mukul Chauhan</i>
						&nbsp;
						<i class="far calendar">May 11, 2019</i>
						<p class="preview-text">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							
						</p>
						<a href="single.html" class="btn read-more">Read More</a>
						
					</div>

				</div>

				<div class="post clearfix">
					<img src="assests/images/image4.jpg" alt="" class="post-image">

					<div class="post-preview">
						<h2><a href="single.html">The strongest and sweetest songs yet remain to be sung</a></h2>
						<i class="fas fa-user"> Mukul Chauhan</i>
						&nbsp;
						<i class="far calendar">May 11, 2019</i>
						<p class="preview-text">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							
						</p>
						<a href="single.html" class="btn read-more">Read More</a>
						
					</div>

				</div>

			</div>

			<!--//Main Content-->

			<div class="sidebar">

			<div class="section search">
				<h2 class="section-title">Search</h2>
				<form action="index.html" method="post">
					<input type="text" name="search-term" class="text-input" placeholder="Search...">
				</form>
			</div>


			<div class="section topics">
				<h2 class="section-title">Topics</h2>
				<ul>
					<li><a href="#">Poems</a></li>
					<li><a href="#">Technology</a></li>
					<li><a href="#">Books</a></li>
					<li><a href="#">Universe</a></li>
					<li><a href="#">Education</a></li>
					<li><a href="#">Memes</a></li>
					<li><a href="#">Famous Quotes</a></li>
				</ul>
			</div>


		</div>
		<!--//Content-->

	</div>
	<!--//Page wrapper-->

	<?php include(ROOT_PATH . "/app/includes/footer.php"); ?>

	<!-- Jquery -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

	<!--Slick Corousel-->
	<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

	<!-- Custom Script-->
	<script src="assests/js/script.js"></script>

</body>
</html>