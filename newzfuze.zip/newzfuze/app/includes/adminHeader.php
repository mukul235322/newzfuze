<header>
		<a class="logo" href="<?php echo BASE_URL . '/index.php'; ?>">
			<h1 class="logo-text">Newz<span>Fuze</span></h1>
		</a>
		<i class="fas fa-bars menu-toggle"></i>
		<ul class="nav">
		
			<li>
				<a href="#">
					<i class="fa fa-user"></i>
				     
			        <i class="fa fa-chevron-down" style="font-size: .8em;"></i>
		        </a>
				<ul>
					<li><a href="#" class="logout">Logout</a></li>
				</ul>
			</li>
		</ul>
</header>